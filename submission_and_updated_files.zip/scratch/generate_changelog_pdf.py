import asyncio
import os
from playwright.async_api import async_playwright

HTML_CONTENT = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<style>
  @page {
    size: A4;
    margin: 10mm 14mm 10mm 14mm;
  }
  * {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
  }
  body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    color: #111827;
    line-height: 1.32;
    font-size: 8.8pt;
    background: #fff;
  }
  .page {
    page-break-after: always;
    position: relative;
    height: 277mm;
    max-height: 277mm;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    overflow: hidden;
  }
  .page:last-child {
    page-break-after: avoid;
  }
  .content {
    flex: 1;
  }
  .footer {
    display: flex;
    justify-content: space-between;
    font-size: 7.8pt;
    color: #6b7280;
    border-top: 1px solid #d1d5db;
    padding-top: 4px;
    margin-top: 6px;
  }
  h1.title {
    font-size: 19pt;
    font-weight: 800;
    color: #132a1c;
    letter-spacing: -0.01em;
    margin-bottom: 2px;
  }
  .subtitle {
    font-size: 10pt;
    font-weight: 700;
    color: #947600;
    margin-bottom: 2px;
  }
  .meta-tagline {
    font-size: 8.2pt;
    color: #4b5563;
    margin-bottom: 6px;
  }
  .table-box {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 6px;
    font-size: 8.3pt;
  }
  .table-box th, .table-box td {
    border: 1px solid #cbd5e1;
    padding: 3.5px 6px;
    vertical-align: top;
    text-align: left;
  }
  .table-box th {
    background-color: #f7f5ed;
    font-weight: 700;
    color: #1f2937;
  }
  .table-box td.label-col {
    width: 25%;
    font-weight: 700;
    background-color: #ffffff;
    color: #1f2937;
  }
  h2.section-title {
    font-size: 10.2pt;
    font-weight: 750;
    color: #111827;
    margin-top: 6px;
    margin-bottom: 2px;
    border-bottom: 1px solid #e5e7eb;
    padding-bottom: 1px;
  }
  p {
    margin-bottom: 4px;
    text-align: justify;
  }
  ul {
    margin-left: 14px;
    margin-bottom: 4px;
  }
  li {
    margin-bottom: 2px;
  }
  strong {
    font-weight: 650;
  }
  .chip {
    display: inline-block;
    padding: 1px 5px;
    border-radius: 4px;
    font-size: 7.5pt;
    font-weight: 650;
  }
  .chip-green { background: #dcfce7; color: #166534; }
  .chip-gold { background: #fef3c7; color: #854d0e; }
  .chip-blue { background: #e0f2fe; color: #075985; }
</style>
</head>
<body>

<!-- PAGE 1 -->
<div class="page">
  <div class="content">
    <h1 class="title">Bhumi Lipi · Changelog & Update Report</h1>
    <div class="subtitle">Complete Summary of System Enhancements, UI Refinements & Hackathon Alignment</div>
    <div class="meta-tagline">LandTech Innovation Hackathon 2026 · Round 1 Technical Submission Report · Track: Digital Land Records & Verification</div>

    <table class="table-box">
      <tr>
        <td class="label-col">Project & Team</td>
        <td><strong>Bhumi Lipi</strong> | Team Leader: <strong>Mohammad Abrar Hasnat</strong> (DIU ID: 253-15-689)</td>
      </tr>
      <tr>
        <td class="label-col">Development Scope</td>
        <td>Frontend Polish, Architectural Compliance, Concept Note 2-Page Strict Alignment, Security & Verification Tests</td>
      </tr>
      <tr>
        <td class="label-col">Verification Baseline</td>
        <td><strong>53/53 Automated Unit Tests Passing</strong> | End-to-End Playwright Browser Walkthrough Clean | 0 Regressions</td>
      </tr>
    </table>

    <h2 class="section-title">1. Executive Summary of Changes</h2>
    <p>Following the release of the official Round 1 Concept Note specifications, the Bhumi Lipi platform underwent comprehensive technical refinements across UI symmetry, typography, accessibility compliance, documentation synchronization, and code cleanliness.</p>
    <ul>
      <li><strong>Official 2-Page Concept Note Synchronization:</strong> Updated <code>docs/CONCEPT_NOTE.md</code> and regenerated <code>docs/Bhumi_Lipi_Concept_Note.pdf</code> into a strict 2-page A4 document matching all 8 hackathon sections verbatim.</li>
      <li><strong>UI Symmetry & Card Alignment:</strong> Solved visual imbalance on the Integrity view by introducing matching monospace hash inputs (84px height), synchronized subtitle heights, and horizontally aligned action rows.</li>
      <li><strong>Typography & Contrast Overhaul:</strong> Enlarged table headers to 16px (weight 800) and data cells to 15px. Replaced low-contrast gold badges with high-contrast accessible <code>.flow-pill</code> components across light, dark, and high-contrast modes.</li>
      <li><strong>AI Disclosure Placement:</strong> Clarified AI assistance strictly in documentation (<code>README.md</code>, <code>docs/CONCEPT_NOTE.md</code>) as mandated by contest rules, while removing redundant AI credits from the citizen-facing interface.</li>
    </ul>

    <h2 class="section-title">2. Frontend Architecture & Visual Innovations</h2>
    <table class="table-box">
      <thead>
        <tr>
          <th style="width: 25%;">Component / View</th>
          <th style="width: 75%;">Enhancements Implemented</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><strong>Integrity & Public Anchor (/#/integrity)</strong></td>
          <td>
            • Converted single-line input into an 84px dual-line <code>textarea.anchor-hash-box</code> to show full 64-char SHA-256 hashes without clipping.<br>
            • Enforced matching 48px min-height subtitles and flex <code>justify-content: space-between</code> on both cards.<br>
            • Horizontally aligned <code>[Copy]</code> and <code>[Verify proof]</code> buttons along the bottom baseline.<br>
            • Positioned the interactive proof verdict banner as a full-width result below the 2-column grid.
          </td>
        </tr>
        <tr>
          <td><strong>About & Lifecycle (/#/about)</strong></td>
          <td>
            • Implemented the <strong>4-Stage Countrywide Implementation Plan</strong> (Pilot, District, Division, National) as an interactive bilingual table.<br>
            • Upgraded the 5-step lifecycle pipeline with accessible <code>.flow-pill</code> design.<br>
            • Retained comprehensive international comparison across 5 nations (Georgia, India, Rwanda, Estonia, Zambia).
          </td>
        </tr>
        <tr>
          <td><strong>Verify & Chain Inspection (/#/verify)</strong></td>
          <td>
            • Character-level diff highlight between expected and actual deed hashes.<br>
            • Avalanche effect visualizer demonstrating how a 1-character tamper flips ~50% of hash bits.
          </td>
        </tr>
        <tr>
          <td><strong>Typography & Tables</strong></td>
          <td>
            • Upgraded <code>.t th</code> table headers to 16px (bold weight 800) and <code>.t td</code> to 15px in <code>web/css/app.css</code>.<br>
            • Loaded dedicated Roboto Mono and Space Mono typefaces for all hashes, seal codes, and khatian numbers.
          </td>
        </tr>
        <tr>
          <td><strong>Accessibility & Responsive Design</strong></td>
          <td>
            • Supported text zoom (100%, 125%, 150%) with dynamic <code>calc()</code> token scaling.<br>
            • Mobile bottom navigation bar for viewports &lt; 768px.<br>
            • High-contrast mode with crisp 2px black borders and zero text underlines.
          </td>
        </tr>
      </tbody>
    </table>
  </div>
  <div class="footer">
    <span>Bhumi Lipi - LandTech Innovation Hackathon 2026 · Technical Update Report</span>
    <span>Page 1</span>
  </div>
</div>

<!-- PAGE 2 -->
<div class="page">
  <div class="content">
    <h2 class="section-title">3. File-by-File Technical Modification Matrix</h2>
    <table class="table-box">
      <thead>
        <tr>
          <th style="width: 25%;">File Path</th>
          <th style="width: 15%;">Change Type</th>
          <th style="width: 60%;">Detailed Description of Technical Changes</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><code>docs/Bhumi_Lipi_Concept_Note.pdf</code></td>
          <td><span class="chip chip-green">Regenerated</span></td>
          <td>Strict 2-page print-ready submission PDF matching the official concept note structure, tables, and pagination.</td>
        </tr>
        <tr>
          <td><code>docs/CONCEPT_NOTE.md</code></td>
          <td><span class="chip chip-blue">Updated</span></td>
          <td>Complete markdown copy of the 8-section concept note with problem statement P2, fraud P3, mutation P4, citizen check P5.</td>
        </tr>
        <tr>
          <td><code>README.md</code></td>
          <td><span class="chip chip-blue">Updated</span></td>
          <td>Updated problem statements, added 4-stage rollout plan table, official document links, and team leader details.</td>
        </tr>
        <tr>
          <td><code>web/js/views/integrity.js</code></td>
          <td><span class="chip chip-gold">Refactored</span></td>
          <td>Symmetric cards alignment, 84px monospace textarea input, Enter-to-submit key handler, full-width proof banner.</td>
        </tr>
        <tr>
          <td><code>web/css/app.css</code></td>
          <td><span class="chip chip-blue">Updated</span></td>
          <td>Table font enlargement (16px/15px), <code>.anchor-hash-box</code> responsive rules (84px desktop, 104px mobile), <code>.flow-pill</code> styles.</td>
        </tr>
        <tr>
          <td><code>web/js/views/about.js</code></td>
          <td><span class="chip chip-blue">Updated</span></td>
          <td>Integrated the 4-stage implementation table (পাইলট, জেলা, বিভাগ, জাতীয়) and high-contrast flow pills.</td>
        </tr>
        <tr>
          <td><code>web/js/app.js</code></td>
          <td><span class="chip chip-gold">Refactored</span></td>
          <td>Added <code>?v=1.0.1</code> query parameter to route imports for cache-busting; updated error boundary reload logic.</td>
        </tr>
        <tr>
          <td><code>web/js/views/check.js</code></td>
          <td><span class="chip chip-blue">Updated</span></td>
          <td>Eliminated text-border collision on chain cards by restoring generous internal padding and robust typography.</td>
        </tr>
        <tr>
          <td><code>web/js/components/seal.js</code></td>
          <td><span class="chip chip-green">Feature</span></td>
          <td>SVG Seal with dynamic states: Genuine (green), Outdated (amber), Forged (red), and rotating cryptographic borders.</td>
        </tr>
        <tr>
          <td><code>web/js/components/chain-view.js</code></td>
          <td><span class="chip chip-green">Feature</span></td>
          <td>Visual chain link renderer with broken-link crack visualization and tamper detection alerts.</td>
        </tr>
      </tbody>
    </table>

    <h2 class="section-title">4. Compliance & Verification Milestones</h2>
    <table class="table-box">
      <tr>
        <td class="label-col">Automated Unit Tests</td>
        <td><strong>53 Passed out of 53</strong> across cryptography, lifecycle, mutation state machine, rules engine, and verifier scripts (Execution time: ~3.2 seconds).</td>
      </tr>
      <tr>
        <td class="label-col">Browser Automation (E2E)</td>
        <td>Playwright end-to-end tests verify QR code rendering, theme toggles, modal dialogs, and verification flows.</td>
      </tr>
      <tr>
        <td class="label-col">Security Architecture</td>
        <td>Strict Content-Security-Policy (CSP), textContent-only DOM rendering (zero XSS), append-only SQLite triggers, rate-limited JSON API.</td>
      </tr>
      <tr>
        <td class="label-col">Independent Verification</td>
        <td>Includes standalone Python script (<code>tools/verify_anchor.py</code>) enabling third-party audit without server dependencies.</td>
      </tr>
    </table>

    <h2 class="section-title">5. Summary of Deliverables Ready for Submission</h2>
    <ul>
      <li>📄 <strong>Concept Note PDF:</strong> <code>docs/Bhumi_Lipi_Concept_Note.pdf</code> (Strict 2-page official submission PDF).</li>
      <li>📄 <strong>Technical Changelog PDF:</strong> <code>docs/Bhumi_Lipi_Changelog_and_Updates.pdf</code> (This 2-page executive summary).</li>
      <li>📄 <strong>Master Architectural Plan:</strong> <code>docs/Bhumi_Lipi_Master_Plan.pdf</code> (Detailed 10-page technical specification).</li>
      <li>💻 <strong>Source Code Repositories:</strong> Clean master branch with 0 uncommitted files, 53 tests passing, and Docker/Render configs.</li>
      <li>📦 <strong>Submission Archives:</strong> <code>all_updated_files.zip</code> and <code>submission_and_updated_files.zip</code>.</li>
    </ul>

    <div style="margin-top: 6px; padding: 5px 8px; background: #f6f3eb; border: 1px solid #d1d5db; border-radius: 4px; font-size: 8.2pt;">
      <strong>Team Declaration:</strong> All land data in Bhumi Lipi is 100% synthetic. No real citizen names, NIDs, or live government records were used. AI coding assistants (Claude, Antigravity) were used for development and are fully disclosed in README.md as per rulebook guidelines.
    </div>
  </div>
  <div class="footer">
    <span>Bhumi Lipi - LandTech Innovation Hackathon 2026 · Technical Update Report</span>
    <span>Page 2</span>
  </div>
</div>

</body>
</html>
"""

async def main():
    html_path = r"C:\Users\AC\Downloads\bhumi-lipi\scratch\changelog_report.html"
    pdf_path = r"C:\Users\AC\Downloads\bhumi-lipi\docs\Bhumi_Lipi_Changelog_and_Updates.pdf"
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(HTML_CONTENT)
    
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page()
        await page.goto(f"file:///{html_path.replace(os.sep, '/')}", wait_until="networkidle")
        await page.pdf(
            path=pdf_path,
            format="A4",
            print_background=True,
            margin={"top": "0mm", "bottom": "0mm", "left": "0mm", "right": "0mm"}
        )
        await browser.close()
    print("Generated Changelog PDF at:", pdf_path)

asyncio.run(main())
