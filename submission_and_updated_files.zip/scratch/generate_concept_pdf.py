import asyncio
import os
from playwright.async_api import async_playwright

HTML_CONTENT = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<style>
  @page {
    size: A4;
    margin: 10mm 14mm 10mm 14mm;
  }
  * {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
  }
  body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    color: #111827;
    line-height: 1.32;
    font-size: 8.8pt;
    background: #fff;
  }
  .page {
    page-break-after: always;
    position: relative;
    height: 277mm;
    max-height: 277mm;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    overflow: hidden;
  }
  .page:last-child {
    page-break-after: avoid;
  }
  .content {
    flex: 1;
  }
  .footer {
    display: flex;
    justify-content: space-between;
    font-size: 7.8pt;
    color: #6b7280;
    border-top: 1px solid #d1d5db;
    padding-top: 4px;
    margin-top: 6px;
  }
  h1.title {
    font-size: 19pt;
    font-weight: 800;
    color: #132a1c;
    letter-spacing: -0.01em;
    margin-bottom: 2px;
  }
  .subtitle {
    font-size: 10pt;
    font-weight: 700;
    color: #947600;
    margin-bottom: 2px;
  }
  .meta-tagline {
    font-size: 8.2pt;
    color: #4b5563;
    margin-bottom: 6px;
  }
  .table-box {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 6px;
    font-size: 8.3pt;
  }
  .table-box th, .table-box td {
    border: 1px solid #cbd5e1;
    padding: 3.5px 6px;
    vertical-align: top;
    text-align: left;
  }
  .table-box th {
    background-color: #f7f5ed;
    font-weight: 700;
    color: #1f2937;
  }
  .table-box td.label-col {
    width: 25%;
    font-weight: 700;
    background-color: #ffffff;
    color: #1f2937;
  }
  h2.section-title {
    font-size: 10.2pt;
    font-weight: 750;
    color: #111827;
    margin-top: 6px;
    margin-bottom: 2px;
  }
  p {
    margin-bottom: 4px;
    text-align: justify;
  }
  ul {
    margin-left: 14px;
    margin-bottom: 4px;
  }
  li {
    margin-bottom: 2px;
  }
  strong {
    font-weight: 650;
  }
</style>
</head>
<body>

<!-- PAGE 1 -->
<div class="page">
  <div class="content">
    <h1 class="title">Bhumi Lipi</h1>
    <div class="subtitle">Tamper-evident deed verification and a linked registration-to-mutation workflow</div>
    <div class="meta-tagline">LandTech Innovation Hackathon 2026 · Round 1 Concept Note · Track: Digital Land Records, Verification & Digitization</div>

    <table class="table-box">
      <tr>
        <td class="label-col">Chosen problem statement</td>
        <td><strong>P2 - Deed & Ownership Verification (main)</strong>. Supporting features from P3 (fraud and double-selling detection), P4 (smart e-mutation workflow) and P5 (citizen pre-purchase verification), built as one lifecycle.</td>
      </tr>
      <tr>
        <td class="label-col">Prototype status</td>
        <td>Working prototype on 100% synthetic data. 53 automatic tests, a real-browser walkthrough and an independent verifier script.</td>
      </tr>
    </table>

    <h2 class="section-title">1. The problem in Bangladesh</h2>
    <p>Land disputes are among the most common civil cases in Bangladesh. Many trace back to three weaknesses in how records are kept and checked:</p>
    <ul>
      <li><strong>Forged or altered deeds.</strong> A paper deed or a photocopy is hard to verify on the spot; buyers and banks usually depend on brokers.</li>
      <li><strong>The same plot sold twice.</strong> Registration happens at the sub-registry office and mutation at the AC Land office. In the gap between the two, a plot can be sold again, and nobody is accountable for how long mutation waits.</li>
      <li><strong>Hard-to-read records for ordinary citizens.</strong> Survey generations (CS, SA, RS, BS) and area units (ana, gonda) are confusing, and many people have low literacy or limited digital skill.</li>
    </ul>
    <p>Bhumi Lipi addresses these within the rule book's own problem statements, rather than adding unrelated features.</p>

    <h2 class="section-title">2. Proposed solution</h2>
    <p>Every registered sale becomes a <strong>signed record in a per-plot hash chain</strong>. Each record is hashed with SHA-256 and signed with Ed25519 (one key per office). A QR seal on the deed leads to a public check page. Anyone can verify a deed copy and get one of three results: <strong>Genuine</strong>, <strong>Outdated</strong> (a valid old deed, but a newer record exists) or <strong>Forged</strong> (the file or seal does not match the registry).</p>
    <p>The same system links registration to mutation: when a sale is registered, the plot is <strong>locked</strong> and a mutation case starts automatically, with <strong>8 automatic checks</strong>, a tracking ID and an officer queue. The lock stays until the AC Land officer approves the mutation. Citizens see the result as a Green / Amber / Red report in Bangla or English.</p>

    <h2 class="section-title">3. Key features (all built and tested)</h2>
    <table class="table-box">
      <thead>
        <tr>
          <th style="width: 25%;">Area</th>
          <th style="width: 75%;">What it does</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><strong>Verification (P2)</strong></td>
          <td>Signed hash chain, append-only database triggers, chain guard, QR seal, deed-file fingerprint check, three verify results.</td>
        </tr>
        <tr>
          <td><strong>Fraud detection (P3)</strong></td>
          <td>11 explainable rules with a risk score, in Bangla and English: fake-seller and double-sale blocks, government-land block, rapid-transfer and survey-mismatch warnings, one active lien per plot (double-mortgage block).</td>
        </tr>
        <tr>
          <td><strong>Smart mutation (P4)</strong></td>
          <td>Auto-start after registration, 8 automatic checks, tracking ID, officer queue, reversal records, and a waiting-days chip (amber at 14 days, red at 30 days) so delays are visible.</td>
        </tr>
        <tr>
          <td><strong>Citizen check (P5)</strong></td>
          <td>Green/Amber/Red report, ownership history, survey table, printable title report. Simple mode for elders and low-literacy users: three-word shape verdicts (Go ahead / Careful / Stop), large text, high contrast, read-aloud when the device has a Bangla voice, and an ana-gonda to decimal helper.</td>
        </tr>
        <tr>
          <td><strong>Trust</strong></td>
          <td>Periodic public Merkle anchor, in-browser proof check, independent verifier script that does not import the app, and an Attack Lab that runs 5 attacks on a private copy (never on the live data).</td>
        </tr>
      </tbody>
    </table>

    <h2 class="section-title">4. System architecture and tech stack</h2>
    <table class="table-box" style="margin-bottom: 0;">
      <thead>
        <tr>
          <th style="width: 25%;">Layer</th>
          <th style="width: 75%;">Technology and role</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><strong>Browser</strong></td>
          <td>Vanilla JavaScript, no build step. Views: Check, Verify, Registrar, Mutation, Bank, Integrity, Lab, About. Bangla and English. Text is inserted with textContent; strict content security policy.</td>
        </tr>
        <tr>
          <td><strong>HTTP layer</strong></td>
          <td>Python standard library server: JSON API, demo roles, rate limit, request-size cap, security headers, path-traversal-safe static files.</td>
        </tr>
        <tr>
          <td><strong>Service layer</strong></td>
          <td>Framework-free Python: register sale, check plot, verify, decide mutation, liens, integrity, anchor, lab. A framework such as FastAPI can replace only the API file later.</td>
        </tr>
      </tbody>
    </table>
  </div>
  <div class="footer">
    <span>Bhumi Lipi - Concept Note - LandTech Innovation Hackathon 2026</span>
    <span>Page 1</span>
  </div>
</div>

<!-- PAGE 2 -->
<div class="page">
  <div class="content">
    <table class="table-box" style="margin-top: 4px;">
      <thead>
        <tr>
          <th style="width: 25%;">Layer</th>
          <th style="width: 75%;">Technology and role</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><strong>Crypto and rules</strong></td>
          <td>SHA-256, Ed25519 per office, Merkle tree. Rules are pure functions with Bangla and English messages, so each decision can be explained.</td>
        </tr>
        <tr>
          <td><strong>Database</strong></td>
          <td>SQLite for the prototype (PostgreSQL planned). Append-only triggers on blocks, anchors, mutation events and audit log, plus a chain-guard trigger, so the database itself enforces the rules.</td>
        </tr>
        <tr>
          <td><strong>Delivery</strong></td>
          <td>Dockerfile, render.yaml, CI, README, SPEC, threat model, demo script. One third-party dependency: cryptography.</td>
        </tr>
      </tbody>
    </table>

    <p style="margin-top: 6px;"><strong>Design principles.</strong> The sealed block format is frozen, so changes are additive only (new columns, tables and rule entries). Unfinished features ship behind feature flags. The verifier ignores unknown fields, so old exports stay checkable as the system grows.</p>

    <p><strong>Honest security claim.</strong> The system is tamper-evident, not tamper-proof: any edit to history is detected by the chain check, the public anchor and the independent verifier. Demo roles stand in for national digital ID and are not real login.</p>

    <h2 class="section-title">5. How it fits international practice at low cost</h2>
    <p>Public descriptions of land systems in Georgia (title fingerprints on a public ledger), Estonia (hash-tree integrity between registries), India (one ID per parcel) and Rwanda (systematic parcel registration) informed the design. Bhumi Lipi adapts the ideas without per-transaction chain fees: office signatures and a hash chain give the proof, and only a periodic Merkle root is published. The software stack is open source. The real cost drivers are hosting, database, hardware keys per office, officer training and the people-time to digitize old records. We have not measured cost savings and make no savings claim.</p>

    <h2 class="section-title">6. Plan for countrywide implementation</h2>
    <table class="table-box">
      <thead>
        <tr>
          <th style="width: 14%;">Stage</th>
          <th style="width: 32%;">Scope</th>
          <th style="width: 54%;">Main work</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><strong>1. Pilot</strong></td>
          <td>One sub-registry office with its AC Land office</td>
          <td>Hardware keys per office, officer training, parallel run beside the existing process, review by land-office staff and law experts.</td>
        </tr>
        <tr>
          <td><strong>2. District</strong></td>
          <td>All offices in one district</td>
          <td>PostgreSQL, role-based real login, monitoring, offline-verifiable QR and a low-bandwidth/PWA mode for villages, SMS/USSD checks.</td>
        </tr>
        <tr>
          <td><strong>3. Division</strong></td>
          <td>Several districts</td>
          <td>Integration with national ID and existing e-mutation and land portals through official agreements; witness co-signing of anchors by three offices.</td>
        </tr>
        <tr>
          <td><strong>4. National</strong></td>
          <td>All offices</td>
          <td>Shared public anchor, independent verifier open to the public, scheduled digitization of old khatians and deeds with Bangla OCR plus human review.</td>
        </tr>
      </tbody>
    </table>

    <p><strong>Roadmap items designed but not yet built:</strong> co-owner share ledger, inheritance (warish) mutation, survey lineage graph, offline map and boundary-overlap rule, offline-signed QR, Bangla OCR with human review, identity and power-of-attorney checks, land-tax check. Legal rules for shares, heirs and tax are demo rules and must be confirmed by a land-law expert before real use.</p>

    <h2 class="section-title">7. Data, privacy and AI-tool disclosure</h2>
    <ul>
      <li>All data is synthetic and created by the team. No real names, NID numbers, phone numbers, addresses or land records are used. Nothing is scraped from any government portal and no live government system is tested.</li>
      <li>AI coding assistants were used during development. Every tool and what it did is listed in the README. Both student members can explain the code and design.</li>
    </ul>

    <h2 class="section-title">8. Team and mentor details</h2>
    <table class="table-box">
      <thead>
        <tr>
          <th style="width: 25%;">Role</th>
          <th style="width: 25%;">Name</th>
          <th style="width: 25%;">DIU ID / Organization</th>
          <th style="width: 25%;">Contact</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><strong>Student 1 (Team Leader)</strong></td>
          <td>Mohammad Abrar Hasnat</td>
          <td>DIU ID: 253-15-689</td>
          <td>[fill in]</td>
        </tr>
        <tr>
          <td><strong>Student 2</strong></td>
          <td>[fill in]</td>
          <td>[fill in]</td>
          <td>[fill in]</td>
        </tr>
        <tr>
          <td><strong>Faculty mentor</strong></td>
          <td>[fill in]</td>
          <td>[fill in]</td>
          <td>[fill in]</td>
        </tr>
        <tr>
          <td><strong>Industry mentor</strong></td>
          <td>[fill in]</td>
          <td>[fill in]</td>
          <td>[fill in]</td>
        </tr>
      </tbody>
    </table>

    <div style="font-size: 9pt; margin-top: 4px;">
      <p><strong>Team name:</strong> [fill in] &nbsp;&nbsp;&nbsp;&nbsp; <strong>Repository:</strong> [GitHub/GitLab link] &nbsp;&nbsp;&nbsp;&nbsp; <strong>Live link:</strong> [Render link]</p>
    </div>
  </div>
  <div class="footer">
    <span>Bhumi Lipi - Concept Note - LandTech Innovation Hackathon 2026</span>
    <span>Page 2</span>
  </div>
</div>

</body>
</html>
"""

async def main():
    html_path = r"C:\Users\AC\Downloads\bhumi-lipi\scratch\concept_note.html"
    pdf_path = r"C:\Users\AC\Downloads\bhumi-lipi\docs\Bhumi_Lipi_Concept_Note.pdf"
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(HTML_CONTENT)
    
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page()
        await page.goto(f"file:///{html_path.replace(os.sep, '/')}", wait_until="networkidle")
        await page.pdf(
            path=pdf_path,
            format="A4",
            print_background=True,
            margin={"top": "0mm", "bottom": "0mm", "left": "0mm", "right": "0mm"}
        )
        await browser.close()
    print("Generated PDF at:", pdf_path)

asyncio.run(main())
