import asyncio
from playwright.async_api import async_playwright

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page(viewport={"width": 1280, "height": 900})
        await page.goto("http://localhost:8000/#/about", wait_until="networkidle")
        await page.wait_for_timeout(300)
        await page.evaluate("""() => {
            import('/js/i18n.js').then(m => {
                m.setTheme('dark');
            });
        }""")
        await page.wait_for_timeout(300)
        await page.reload(wait_until="networkidle")
        await page.wait_for_timeout(400)
        await page.screenshot(path="C:/Users/AC/Downloads/bhumi-lipi/scratch/about_dark_new.png", full_page=True)
        await browser.close()
        print("Captured about_dark_new.png")

asyncio.run(main())
