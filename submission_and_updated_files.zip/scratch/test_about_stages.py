import asyncio
from playwright.async_api import async_playwright

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page(viewport={"width": 1280, "height": 900})
        
        errors = []
        page.on("pageerror", lambda err: errors.append(str(err)))
        page.on("console", lambda msg: errors.append(msg.text) if msg.type == "error" else None)
        
        await page.goto("http://localhost:8000/#/about", wait_until="networkidle")
        await page.wait_for_timeout(400)
        await page.screenshot(path="C:/Users/AC/Downloads/bhumi-lipi/scratch/about_new_page.png", full_page=True)
        await browser.close()
        
        if errors:
            print("Errors found:", errors)
        else:
            print("Page loaded with zero errors!")

asyncio.run(main())
